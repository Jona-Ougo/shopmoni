<div class="alert red">
    <?php echo lang('search_error');?>
</div>