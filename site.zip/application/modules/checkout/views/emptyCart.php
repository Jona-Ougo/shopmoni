<div class="container product-page">
    <div class="st-default main-wrapper clearfix">
        <?=CI::breadcrumbs()->generate(); ?>
        <br/>
        <div class="row">
            <div class="col-md-12">
                <div class="">
                    <h4><?php echo lang('empty_view_cart');?></h4> <br/>
                    <a href="<?php echo site_url();?>" class="button">
                        <?php echo lang('continue_shopping');?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
</div>

