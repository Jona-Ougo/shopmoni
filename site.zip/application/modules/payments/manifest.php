<?php

$routes[] = ['GET|POST', '/admin/payments', 'GoCart\Controller\AdminPayments#index'];