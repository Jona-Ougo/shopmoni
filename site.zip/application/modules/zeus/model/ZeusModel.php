<?php
/**
 * Zeus Model Class
 *
 * @package Zeus
 * @subpackage Models
 * @category Zeus
 * @author Olaiya Segun
 * @link http://twitter.com/massivebrains00
 */

Class ZeusModel
{

    public function __construct()
    {
        
    }

}