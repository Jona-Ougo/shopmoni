<!-- START FOOTER -->
            <div class="footer">
              <table border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="content-block">
                    <span class="apple-link">Thank You for using Shopmoni.com</span>
                    <br> Cheers, Shopmoni Team
                  </td>
                </tr>
                <tr>
                  <td class="content-block powered-by">
                    Have questions? Get in touch with us via Facebook or Twitter, or fill our contact form.
                  </td>
                </tr>
              </table>
            </div>

            <!-- END FOOTER -->
            
<!-- END CENTERED WHITE CONTAINER --></div>
        </td>
        <td>&nbsp;</td>
      </tr>
    </table>
  </body>
</html>