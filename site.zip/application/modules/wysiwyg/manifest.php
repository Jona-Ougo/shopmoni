<?php

$routes[] = ['GET|POST', '/admin/wysiwyg/upload_image', 'GoCart\Controller\AdminWysiwyg#upload_image'];
$routes[] = ['GET|POST', '/admin/wysiwyg/get_images', 'GoCart\Controller\AdminWysiwyg#get_images'];