<?php

$lang['charge_on_delivery'] = 'Charge on Delivery';
$lang['enabled'] = 'Enabled';
$lang['disabled'] = 'Disabled';
$lang['processing_error'] = 'There was an error processing your payment';