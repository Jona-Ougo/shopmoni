<?php

$lang['dhl'] = 'DHL';
$lang['enabled'] = 'Enabled';
$lang['disabled'] = 'Disabled';
$lang['rate'] = 'Rate';