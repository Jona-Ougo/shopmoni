<?php

$lang['paystack'] = 'Paystack';
$lang['enabled'] = 'Enabled';
$lang['disabled'] = 'Disabled';
$lang['processing_error'] = 'There was an error processing your payment';