<div style="text-align: center">
<div class="page-header">
    <h1><?php echo lang('paystack_webpay');?></h1>
</div>

<?php echo $body ; ?>
<br />
Click <a href="<?php echo site_url('/') ; ?>">here</a> to go home
</div>